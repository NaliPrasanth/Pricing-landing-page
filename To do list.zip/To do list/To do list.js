const newTaskInput = document.getElementById('new-task');
const addTaskButton = document.getElementById('add-task-button');
const tasksList = document.getElementById('tasks-list');

// Get tasks from local storage (if available)
let tasks = localStorage.getItem('tasks') ? JSON.parse(localStorage.getItem('tasks')) : [];

// Function to add a new task
function addTask(task) {
  const taskItem = document.createElement('li');
  const checkbox = document.createElement('input');
  checkbox.type = 'checkbox';
  checkbox.addEventListener('change', function() {
    taskItem.classList.toggle('completed');
  });
  const taskText = document.createTextNode(task);
  const deleteButton = document.createElement('button');
  deleteButton.textContent = 'Delete';
  deleteButton.addEventListener('click', function() {
    tasksList.removeChild(taskItem);
    tasks = tasks.filter(t => t.text !== task);
    localStorage.setItem('tasks', JSON.stringify(tasks));
  });
  taskItem.appendChild(checkbox);
  taskItem.appendChild(taskText);
  taskItem.appendChild(deleteButton);
  tasksList.appendChild(taskItem);
  tasks.push({text: task, completed: false});
  localStorage.setItem('tasks', JSON.stringify(tasks));
  newTaskInput.value = '';
}

// Render existing tasks from local storage
tasks.forEach(task => addTask(task.text));

// Add task button click event listener
addTaskButton.addEventListener('click', function() {
  const newTask = newTaskInput.value.trim();
  if (newTask) {
    addTask(newTask);
  }
});
